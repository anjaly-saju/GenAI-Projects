<!DOCTYPE html>
<html>
<head>
    <title>Register User</title>
</head>
<body>
<h1>Register</h1>
<form method="POST" action="{{ route('employeesStore') }}">
            <div class="form-group">
                <label for="emp_id">Employee ID</label>
                <input type="text" name="emp_id" id="emp_id" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" name="name" id="name" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="date_of_joining">Date of Joining</label>
                <input type="date" name="date_of_joining" id="date_of_joining" class="form-control" required>
            </div>

        <div>
        <button type="submit">Register</button>
        </div>

    
    

</form>
</body>
</html>
