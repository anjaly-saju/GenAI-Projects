<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password</title> 
    <link rel="stylesheet" href="{{ asset('css/styles.css') }}">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <style>
        body {
            font-family: 'Arial', sans-serif; 
            padding-top: 56px; /* Adjust this value based on your top navbar height */
        }

        .top-header {
            background-color: #020016; /* Set your preferred background color */
            color: white;
            padding: 10px;
        }
 
        .container {
        min-height: 60vh;
        }
        .form-control {
        display: block;
        width: 100%;
        height: calc(1.5em + .75rem + 2px);
        padding: .375rem .75rem;
        font-size: 1rem;
        font-weight: 400;
        line-height: 1.5;
        color: #495057;
        background-color: #fff;
        background-clip: padding-box;
        border: 1px solid #ced4da;
        border-radius: .25rem;
        transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
        }
        .form-container {
        margin: auto;
        padding: 2%;
        width: 35%;
        border: 1px solid var(--light-grey);
        box-shadow: 0 2px 10px var(--light-grey);
        margin-top: 138px;
        border-radius: 10%;
        background:   #b2b1ff20;
        }
        .star_submitbtn,
        .clear_submitbtn {
        background-color: red;
        cursor: pointer;
        color: white;
        border: none;
        border-radius: 5px;
        transition: background-color 0.3s;
       }
        
    </style>
</head>

<body>

     <!-- Top Header -->
     <nav class="navbar navbar-dark fixed-top bg-custom-white top-header" style="height: 61px; border-radius: 10px">
    <a class="navbar-brand" style="margin-top: -66px;" href="#"> </a>
    <div class="sidebar-header">
        <div class="star-heading" style=" margin-top: -22px;margin-right: 584px;">
            <h3><strong style="font-family: space-age;color: white;">Logo</strong></h3>
               
        </div>
    </div>
    
    </nav>
 
    <div class="container">
        <div class="form-container">
            <div class="alert alert-danger" role="alert" style="display: none;" id="errorAlert">Incorrect login details.
                Please try again.
            </div>
            <h4>Change Password</h4>

            <form method="POST" action="{{ route('password.change') }}">
                @csrf <!-- CSRF Protection -->

                <div class="form-group">
                    <label for="oldPass">Old Password</label>
                    <input type="password" name="oldPass" id="oldPass" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="newPass">New Password</label>
                    <input type="password" name="newPass" id="newPass" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="conPass">Confirm Password</label>
                    <input type="password" name="conPass" id="conPass" class="form-control" required>
                </div>

                <div>
                    @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                            <h5 class="error-message">{{ $error }}</h5>
                            @endforeach
                        </ul>
                    </div>
                    @endif
                </div>
                <div class="button-container">
            <button type="submit" id="submitBtn" class="btn star_submitbtn">Submit</button>
            <button type="button" id="backBtn" class="btn btn-secondary" onclick="goBack()">Back</button>
            </div>
            </form>
        </div>
    </div>
     
    <script>
        function goBack() {
            window.history.back();
        }
    </script>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"
        integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js"
        integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6"
        crossorigin="anonymous"></script>

    <!-- Add your additional scripts here -->

</body>

</html>
