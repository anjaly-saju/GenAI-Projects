<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title> 
    <link rel="stylesheet" href="{{ asset('css/styles.css') }}">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <style>
        body {
            font-family: 'Arial', sans-serif; 
            padding-top: 56px; /* Adjust this value based on your top navbar height */
        }

        .top-header {
            background-color: #020016; /* Set your preferred background color */
            color: white;
            padding: 10px;
        }

        .sidebar {
            position: fixed;
            top: 56px; /* Adjust this value based on your top navbar height */
            left: 0;
            bottom: 0;
            width: 250px;
            background-color: #020016; /* Set your preferred background color */
        }

        .sidebar-header {
            padding: 15px;
            text-align: center;
        }

        .content {
            
            padding: 15px;
        }
        .sidebar .navbar-nav .nav-item > a {
        color:#ffffff ;
        
        }
        .container {
        min-height: 60vh;
        }
        .form-control {
        display: block;
        width: 100%;
        height: calc(1.5em + .75rem + 2px);
        padding: .375rem .75rem;
        font-size: 1rem;
        font-weight: 400;
        line-height: 1.5;
        color: #495057;
        background-color: #fff;
        background-clip: padding-box;
        border: 1px solid #ced4da;
        border-radius: .25rem;
        transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
        }
        .form-container {
        margin: auto;
        padding: 2%;
        width: 35%;
        border: 1px solid var(--light-grey);
        box-shadow: 0 2px 10px var(--light-grey);
        margin-top: 138px;
        border-radius: 10%;
        background:   #b2b1ff20;
        }
        .star_submitbtn,
        .clear_submitbtn {
        background-color: red;
        cursor: pointer;
        color: white;
        border: none;
        border-radius: 5px;
        transition: background-color 0.3s;
       }
       .stars {
       width: 30%; /* Adjust the width as needed */
       /* margin-left: 20px; */
       margin-top: 20px; /* Adjust the top margin as needed */
       margin-bottom: 10px; /* Adjust the bottom margin as needed */
       /* border: 2px solid rgb(220, 250, 52); */
       height: 60vh;
       display: flex;
       flex-direction: column;
       /* justify-content: space-between; */
       align-items: flex-start;
       }
       .intro1 {
    
       list-style-type: none;
       }

      .intro2 {
       list-style-type: none;
      }

     .instructions {
     }

     .submenu {
      display: none;
      list-style-type: none;
      margin-left: 15px;
      }

     .submenu a {
     text-decoration: none;
     color: white;
     }

     .submenu a:hover {
     color: grey;
     }
     .submenu.show {
     display: block;
     }

    </style>
</head>

<body>

    <!-- Top Header -->
    <nav class="navbar navbar-dark fixed-top bg-custom-white top-header" style="height: 61px; border-radius: 10px">
    <a class="navbar-brand" style="margin-top: -66px;" href="#"> </a>
    <div class="sidebar-header">
        <div class="star-heading" style=" margin-top: -22px;margin-right: 584px;">
            <h3><strong style="font-family: space-age;color: white;">Logo</strong></h3>
               
        </div>
    </div>
    
    </nav>

    <!-- Sidebar -->
    <nav class="navbar navbar-dark fixed-top sidebar" style="margin-top: -56px; border-radius: 25px;">
    <!-- Add your sidebar links or content here -->
    <div class="nav-item" style="margin-top: -244px;">
    <a class="nav-link" href="{{ route('logout') }}">
        <span style="color: white;"><strong>Hi {{ $data->name }} </strong></span>
    </a>
</div> 

    <ul class="navbar-nav" style="margin-top: -446px;margin-left: 26px">
        <br>
         
        <li class="nav-item">
    <a class="nav-link" href="home">
        <i class="fas fa-home"></i> <strong>Home</strong>
    </a>
</li>
 
<li class="nav-item">
    <a class="nav-link" href="manageapprovals">
        <i class="fas fa-check-circle"></i> <strong>Manage Approvals<i class="fas fa-angle-right dropdown"style="margin-left: 19px;"></i></strong>
    </a>
    <ul class="submenu">
    <li><a href="manageapprovals#pending-list" id="qp-sub-1"><i class="fas fa-clock"></i> Pending List</a></li>
    <li><a href="manageapprovals#accepted-list" id="qp-sub-2"><i class="fas fa-check-circle"></i> Accepted List</a></li>
    <li><a href="manageapprovals#rejected-list" id="qp-sub-3"><i class="fas fa-times-circle"></i> Rejected List</a></li>
</ul>
</li>
 
<li class="nav-item">
    <a class="nav-link" href="manageemployees">
        <i class="fas fa-users"></i> <strong>Manage Employees<i class="fas fa-angle-right dropdown"style="margin-left: 6px;"></i></strong>
    </a>
    <ul class="submenu">
    <li><a href="manageemployees#active-list"><i class="fas fa-check-circle"></i> Active List</a></li>
    <li><a href="manageemployees#inactive-list"><i class="fas fa-times-circle"></i> Inactive List</a></li>
    <li><a href="manageemployees#add-employee"><i class="fas fa-user-plus"></i> Add Employee</a></li>
    </ul>
</li>
 
<li class="nav-item">
    <a class="nav-link" href="manageroles">
        <i class="fas fa-cogs"></i> <strong>Manage Roles</strong>
    </a>
</li>
 
<li class="nav-item">
    <a class="nav-link" href="history">
        <i class="fas fa-history"></i> <strong>History</strong>
    </a>
</li>

    <li class="nav-item">
    <a class="nav-link" href="{{ route('password.change.form') }}">
        <i class="fas fa-key"></i> <strong>Change Password</strong>
    </a>
</li>
<li class="nav-item">
    <a class="nav-link" href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
        <i class="fas fa-sign-out-alt"></i> <strong>Logout</strong>
    </a>
    <form id="logout-form" method="POST" action="{{ route('logout') }}" style="display: none;">
        @csrf <!-- CSRF Protection -->
        <button class="dropdown-item" type="submit">Logout</button>
    </form>
</li>

  </ul>
  
    </nav>
    
     
    <div class="container">
        <div class="form-container"style="margin-top:125px; margin-left:300px;">
        <div class="content">
        <h3>Give Star</h3>
        <br>
        <form method="POST" action="{{ route('giveStars') }}" id="starForm">
            @csrf
            <div class="form-group">
                <label for="to_emp_id">Select an Employee:</label>
                <select name="to_emp_id" id="to_emp_id" class="emp-list form-control" required>
                    <option value="">Select Here</option>
                    @foreach ($employees as $employee)
                    @if ($employee->emp_id !== $data->emp_id)
                    <option value="{{ $employee->emp_id }}">{{ $employee->name }}</option>
                    @endif
                    @endforeach
                </select>
            </div>
            
            <div class="form-group">
        <label for="star_points">Choose Star</label>
       
        <input type="text" name="star_points" id="star_points" class="emp-list form-control" readonly>
         </div>
            
        <div class="form-group">
       <label for="comment">Comment:</label>
        <textarea name="comment" cols=37 style="border-radius: 6px;"></textarea>
       </div>

            <div class="button-container">
            <button type="submit" id="submitBtn" class="btn star_submitbtn">Submit</button>
            <button type="reset" class="btn clear_submitbtn">Clear</button>
            </div>
       </form>
       </div></div>
       <!-- HTML for star images -->
       <div class="form-group">
                
       <input type="hidden" name="star_points" id="star_points">
       <div class="stars" style="margin-left: 750px; margin-top: -370px">
       <span class="gold star" data-star="gold"><img src="{{ asset('images/gold_star_main.png') }}" alt="Gold Star"></span>
       <span class="silver star" data-star="silver"><img src="{{ asset('images/silver_star_main.png') }}" alt="Silver Star"></span>
       <span class="bronze star" data-star="bronze"><img src="{{ asset('images/Bronze_Star_Main.png') }}" alt="Bronze Star"></span>
       </div>
       </div>
       
       <!--   total points -->
             
         <div class="container">
        <div class="form-container" style="margin-top: -400px;height: 183px; margin-left: 970px;width: 200px; background-color:#9c27b030; ">
        <div class="content">
                <h4><strong>Your Total Points</strong></h4>
                <div class="total-points" style="margin-top: 0px; margin-left: 50px; color: #3E2723;">
                    <h2>{{ $totalPoints }}</h2>
                </div> 
        </div></div></div>

<!-- Java Script code -->
   
        <script>
            // nav expand collapse
document.addEventListener("DOMContentLoaded", function () {
    const submenuLinks = document.querySelectorAll('.nav-item .nav-link');

    submenuLinks.forEach(link => {
        link.addEventListener('click', function (e) {
            const submenu = this.nextElementSibling;

            if (submenu) {
                e.preventDefault();
                submenu.classList.toggle('show');
            }
        });
    });
});

            // star giving JS
      document.addEventListener("DOMContentLoaded", function () {
    const starForm = document.getElementById("starForm");
    const starPointsText = document.getElementById("star_points");
    const starPointsHidden = document.getElementById("star_points_hidden");
    const clearBtn = document.getElementById("clearBtn");

    const stars = document.querySelectorAll(".stars .star");
    stars.forEach((star) => {
        star.addEventListener("click", function () {
            const selectedStar = this.getAttribute("data-star");

            // Update the text box with the selected star points
            if (starPointsText !== document.activeElement) {
                starPointsText.value = selectedStar === "gold" ? "15" : selectedStar === "silver" ? "10" : "5";
            }

            // Update the hidden input for form submission
            starPointsHidden.value = starPointsText.value;
        });
    });

    // Clear form data when clicking on the "Clear" button
    clearBtn.addEventListener("click", function () {
        starForm.reset();
    });
});


    </script>
    <!-- Bootstrap JS and Popper.js -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
