<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StarProgram extends Model
{
    use HasFactory;
    protected $table = 'star_program';
    // Define fillable fields if needed
    protected $fillable = ['to_emp_id', 'star_date', 'description', 'star_id', 'star_points'];
}
