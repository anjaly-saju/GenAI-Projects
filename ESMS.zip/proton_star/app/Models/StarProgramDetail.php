<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StarProgramDetail extends Model
{
    use HasFactory;
    protected $table = 'star_program_details';
    // Define fillable fields if needed
    protected $fillable = ['from_emp_id','from_emp_name' ,'to_emp_id','to_emp_name', 'star_points', 'date', 'reason', 'action', 'remark'];
}
