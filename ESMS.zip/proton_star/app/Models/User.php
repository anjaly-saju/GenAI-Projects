<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Support\Facades\DB;

class User extends Authenticatable
{
   
    use HasFactory;
    
    protected $table = 'users';
   

    protected $fillable = [
        
        'emp_id', 
        'name',
        'date_of_joining',
        'role',
        'date_of_exit',
        'password',
        'star_points',
        'employee_status',
        'image',
    ];
    
}
