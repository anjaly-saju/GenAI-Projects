<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Http\Request;
use App\Models\User; 
class AuthController extends Controller
{
    public function authenticate(Request $request)
    {
        $credentials = $request->only('emp_id', 'password');
        $user = User::where('emp_id', $request->emp_id)->first();
    // echo $user;
    // echo "User role: " . $user->role . "\n";
        if (Auth::attempt($credentials)) { 
                $request->session()->put('emp_id', $user->emp_id);
                $user = Auth::user();

            if ($user->role === 'Admin') {
                return redirect('home');

            } elseif ($user->role === 'Team Incharge') {
                // return view('teamincharge.hrhome');
                return redirect('hrhome');
            } else {
                // Add more conditions for other roles if needed
                // return view('teammember.emphome');
                return redirect('emphome');

            // echo $user;
            
            }
        } else {
            // echo $user;
            echo "User not authenticated";
            
        }
    }

    public function logout()
    {
        Auth::logout();
        return redirect('/login');
    }

}
