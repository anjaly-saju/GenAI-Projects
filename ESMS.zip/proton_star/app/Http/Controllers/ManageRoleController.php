<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\Models\User; 
use App\Models\StarProgramDetail;
use App\Models\StarProgram;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class ManageRoleController extends Controller
{
    public function activelist()
    {
        $data = array();
        if (session::has('emp_id')) {
            $employees = User::select('emp_id', 'name')->get();
            $data = User::where('emp_id', session()->get('emp_id','name'))->first();

            $activeemp = User::where('employee_status', 'Active')
            ->select('emp_id','name','role')
            ->get();

            $member = User::where('employee_status', 'Active')
               ->where('role', 'Team Member')
               ->select('name','emp_id')
               ->get();

            $incharge = User::where('employee_status', 'Active')
            ->where('role', 'Team Incharge')
            ->select('name','emp_id')
            ->get();

            $admin = User::where('employee_status', 'Active')
            ->where('role', 'Admin')
            ->select('name','emp_id')
            ->get();

            return view('admin.manageroles', compact('activeemp','member','incharge','admin','data'));
           
        }
    }

    public function updateRoles(Request $request)
    {
        $rolesData = $request->input('role');
    
        foreach ($rolesData as $empId => $roles) {
            // Retrieve the employee by emp_id
            $employee = User::where('emp_id', $empId)->first();
    
            if ($employee) {
                // Map the keys to the enum values
                $mappedRoles = [];
                foreach ($roles as $roleKey => $value) {
                    switch ($roleKey) {
                        case 'team_member':
                            $mappedRoles[] = 'Team Member';
                            break;
                        case 'team_incharge':
                            $mappedRoles[] = 'Team Incharge';
                            break;
                        case 'admin':
                            $mappedRoles[] = 'Admin';
                            break;
                        // Add more cases if needed
                    }
                }
                
                // Update the roles for the employee using sync
                DB::table('users')
                     ->where('emp_id', $empId)
                    ->update(['role' => implode(', ', $mappedRoles)]);
            }
        }
    
        // Redirect or respond as needed
        return redirect()->back()->with('success', 'Roles updated successfully!');
    }
    

}


