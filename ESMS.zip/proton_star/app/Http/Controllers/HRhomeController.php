<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\Models\User; 
use App\Models\StarProgramDetail;
use App\Models\StarProgram;

class HRhomeController extends Controller
{
    public function index()
{

    $data = array();
    if (session::has('emp_id')) {

        $empId = session('emp_id');

        $employees = User::select('emp_id', 'name')->get();
        
        $data = User::where('emp_id', session()->get('emp_id'))->first();

        $totalPoints = StarProgram::where('to_emp_id', session()->get('emp_id'))->sum('star_points');

        return view('teamincharge.hrhome', compact('data' , 'employees', 'totalPoints'));

        echo $empId;
    } else {
        echo "User Not Authenticated";
    }

}  
public function giveStars(Request $request)
{
    $requestData = array();
    $from_emp_id = session('emp_id'); 
   
    $from_name = User::where('emp_id', $from_emp_id)
    ->select('name')->first();

    $to_emp_id = $request['to_emp_id']; 
    $to_name = User::where('emp_id', $to_emp_id)
    ->select('name')->first();
    
    // Check if 'from_emp_id' is not null before inserting
    if ($from_emp_id !== null) {
        $requestData = $request->all();
        $requestData['from_emp_id'] = $from_emp_id;
        $requestData['from_emp_name'] = $from_name['name'];
        $requestData['to_emp_id'] = $requestData['to_emp_id'];  
        $requestData['to_emp_name'] = $to_name['name']; 
        $requestData['star_points'] = $requestData['star_points'];  
        $requestData['date'] = now();  
        $requestData['reason'] =  $requestData['comment'];    


        $star = StarProgramDetail::create($requestData);

        return response()->json(['message' => 'Star given successfully', 'star' => $star]);
        // echo $star;
    } else {
        // Handle the case where 'from_emp_id' is null (e.g., redirect, return an error response, etc.)
        return response()->json(['message' => 'Failed to retrieve authenticated user']);
    } 
}
}
