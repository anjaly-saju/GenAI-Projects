<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\Models\User; 
use App\Models\StarProgramDetail;
use App\Models\StarProgram;

class HRmanageemployeesController extends Controller
{
    public function employeeList()
{
    $data = array();
    if (session::has('emp_id')) {
        $employees = User::select('emp_id', 'name')->get();
        $data = User::where('emp_id', session()->get('emp_id'))->first();

    // Retrieve entries with 'employee_status' status as 'Active'
    $activeList = User::where('employee_status', 'Active')
        ->select('emp_id','name','star_points')
        ->get();

                
        // Retrieve entries with 'action' status as 'accept'
    $inactiveList = User::where('employee_status', 'Inactive')
        ->select('emp_id','name','star_points')
        ->get();


    return view('teamincharge.hrmanageemployees', compact('activeList' , 'inactiveList','data')); 

    }
    
}
}
