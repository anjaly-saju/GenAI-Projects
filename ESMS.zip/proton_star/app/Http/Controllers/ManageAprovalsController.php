<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\Models\User; 
use App\Models\StarProgramDetail;
use App\Models\StarProgram;

class ManageAprovalsController extends Controller
{
     
    public function pendingList()
{
    $data = array();
    if (session::has('emp_id')) {
        $employees = User::select('emp_id', 'name')->get();
        $data = User::where('emp_id', session()->get('emp_id', 'name'))->first();

    // Retrieve entries with 'action' status as 'pending'
    $pendingList = StarProgramDetail::where('action', 'Pending')
    ->where('from_emp_id', '!=', session()->get('emp_id'))
    ->where('to_emp_id', '!=', session()->get('emp_id'))
    ->select('id', 'from_emp_id', 'to_emp_id', 'from_emp_name', 'to_emp_name', 'star_points', 'date', 'reason', 'action', 'remark')
    ->get();

        // Retrieve entries with 'action' status as 'accept'
    $acceptList = StarProgramDetail::where('action', 'Accept')
    ->select('id','from_emp_id', 'to_emp_id','from_emp_name', 'to_emp_name', 'star_points', 'date', 'reason', 'action', 'remark')
    ->get();

    // Retrieve entries with 'action' status as 'pending'
    $rejectList = StarProgramDetail::where('action', 'Reject')
        ->select('id','from_emp_id', 'to_emp_id','from_emp_name', 'to_emp_name', 'star_points', 'date', 'reason', 'action', 'remark')
        ->get();

    return view('admin.manageapprovals', compact('pendingList' , 'acceptList','rejectList','data'));
 
    }
    
}
public function acceptstar(Request $request)
{
    $starId = $request->input('id');

    $pendingEntry = StarProgramDetail::where('id', $starId)  
        ->select('id', 'from_emp_id','from_emp_name', 'to_emp_name', 'to_emp_id', 'star_points', 'date', 'reason', 'action', 'remark')
        ->get('id')->first();

    if ($pendingEntry) { 

        $pendingEntry->action = 'Accept';
        $pendingEntry->save();
              
        $requestData = array(); 
 
            $requestData['to_emp_id'] = $pendingEntry->to_emp_id;
            $requestData['star_date'] =   $pendingEntry->date;
            $requestData['description'] = $pendingEntry->reason; 
            $requestData['star_id'] = $pendingEntry->id;
            $requestData['star_points'] =  $pendingEntry->star_points;   
    
    
            $star = StarProgram::create($requestData);

      // Calculate total points for the specific employee after accepting the star program
      $totalPoints = StarProgram::where('to_emp_id', $pendingEntry->to_emp_id)->sum('star_points');

      // Update the total points for the employee in the User table
      $user = User::where('emp_id', $pendingEntry->to_emp_id)->first();

      if ($user) {
          $user->star_points = $totalPoints;
          $user->save();
      }
         
        return redirect('manageapprovals');
    } else {
        echo "Star entry not found for ID:  $pendingEntry";
    }
}

public function rejectstar(Request $request)
{
    
    $starId = $request->input('id');

    $pendingEntry = StarProgramDetail::where('id', $starId)
        ->select('id', 'from_emp_id', 'to_emp_id','from_emp_name', 'to_emp_name', 'star_points', 'date', 'reason', 'action', 'remark')
        ->get('id')->first();

    if ($pendingEntry) { 

     

        $pendingEntry->action = 'Reject';
        $pendingEntry->save();
        

        return redirect('manageapprovals');
    } else {
        echo "Star entry not found for ID:  $pendingEntry";
    }
}
}