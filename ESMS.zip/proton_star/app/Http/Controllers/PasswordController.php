<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException; // Make sure to include this
use App\Models\User;

class PasswordController extends Controller
{
    public function showChangePasswordForm()
    {

        $data = array();
    if (session::has('emp_id')) {
        $employees = User::select('emp_id', 'name')->get();
        $data = User::where('emp_id', session()->get('emp_id','name'))->first();
    }
        return view('auth.changepassword', compact( 'data'));
    }

    public function changePassword(Request $request)
    {
        $request->validate([
            'oldPass' => 'required',
            'newPass' => 'required|min:8',
            'conPass' => 'required|same:newPass',
        ]);

        $user = auth()->user();

        // Check if the old password matches the current password
        if (!Hash::check($request->oldPass, $user->password)) {
            throw ValidationException::withMessages([
                'oldPass' => ['Incorrect old password.'],
            ]);
        }

        // Update the user's password
        $user->update([
            'password' => Hash::make($request->newPass),
        ]);

        // Log the user out after changing the password
        Auth::logout();

        // Redirect to the login page with a success message
        return redirect()->route('login')->with('success', 'Password changed successfully. Please login with your new password.');
    }
}
