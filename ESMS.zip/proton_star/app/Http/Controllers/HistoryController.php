<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\Models\User; 
use App\Models\StarProgramDetail;
use App\Models\StarProgram;
use App\Models\History;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class HistoryController extends Controller
{
    
    public function history(Request $request)
{
    $data = array();
    if (session::has('emp_id')) {
        $employees = User::select('emp_id', 'name')->get();
        $data = User::where('emp_id', session()->get('emp_id','name'))->first();
    }

    $year = $request->input('year');

     

    // Retrieve stars history, assuming the History model has the necessary columns
    $starsHistory = History::select('to_emp_id', 'star_points', 'star_date')
        ->whereYear('star_date', $year)
        ->get();

        $name = [];

        foreach ($starsHistory as $history) {
            $user = User::where('emp_id', $history->to_emp_id)->select('name')->first();
        
            // Check if a user was found before accessing the name
            if ($user) {
                $name[] = $user->name;
            }
        }
        
     

        return view('admin.history', compact('starsHistory','name', 'year', 'data'));
}

}
 
