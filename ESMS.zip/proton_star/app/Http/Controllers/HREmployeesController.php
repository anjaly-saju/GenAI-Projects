<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use App\Models\User; 
use App\Models\StarProgramDetail;
use App\Models\StarProgram;

class HREmployeesController extends Controller
{
    public function registerForm()
    {
        return view('auth.hrregister'); // Create a view for the login form
    }
    public function store(Request $request)

    {
        $validatedData = $request->validate([
            'emp_id' => 'required',
            'name' => 'required',
            'date_of_joining'=> 'required',
            'password'=> 'required',
            // Add validation rules for other fields...
        ]);
    
        $employee = new User();
    
        $employee->emp_id = $validatedData['emp_id'];
        $employee->name = $validatedData['name'];
        $employee->date_of_joining = $validatedData['date_of_joining'];    
        $employee->password = bcrypt($validatedData['password']);
    
        $employee->save();
    
        return "Employee created successfully!";
    }
}
