<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class RoleRedirectMiddleware
{
    // app/Http/Middleware/RoleRedirectMiddleware.php

public function handle($request, Closure $next, ...$roles)
{
    if (auth()->check() && in_array(auth()->user()->role, $roles)) {
        switch (auth()->user()->role) {
            case 'team_member':
                return redirect()->route('teammember.home');
            case 'admin':
                return redirect()->route('admin.home');
            case 'team_incharge':
                return redirect()->route('teamincharge.home');
            // Add more cases for other roles if needed
            default:
                return redirect('/home'); // Default redirect
        }
    }

    return $next($request);
}
}
