<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\PasswordController;
// Admin
use App\Http\Controllers\HomeController;
use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\ManageAprovalsController;
use App\Http\Controllers\ManageEmployeesController;
use App\Http\Controllers\ManageRoleController;
use App\Http\Controllers\HistoryController;
// Team Incharge
use App\Http\Controllers\HRhomeController;
use App\Http\Controllers\HRmanageaprovalsController;
use App\Http\Controllers\HRmanageemployeesController;
use App\Http\Controllers\HREmployeesController;
// Team Member
use App\Http\Controllers\TMhomeController;

// login page Route
Route::get('/login', function () {
return view('auth.login');
})->name('login');
Route::post('/login', [AuthController::class, 'authenticate'])->name('login.authenticate');
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
// Change Password
Route::get('/changepassword', [PasswordController::class, 'showChangePasswordForm'])->name('password.change.form');
Route::post('/change-password', [PasswordController::class, 'changePassword'])->name('password.change');

// ADMIN ROUTES

  // Home page route
  Route::get('/home', [HomeController::class, 'index'])->middleware('login');
  Route::post('/home', [HomeController::class, 'giveStars'])->name('giveStars');

  // Manage Approvals route
  Route::get('/manageapprovals', [ManageAprovalsController::class, 'pendingList'])->name('pending.list');
  Route::post('/accept', [ManageAprovalsController::class, 'acceptstar'])->name('acceptstar'); 
  Route::post('/reject', [ManageAprovalsController::class, 'rejectstar'])->name('rejectstar');
 
  // Manage Employees route
  Route::get('/manageemployees', [ManageEmployeesController::class, 'employeeList'])->name('employee.List');
  Route::get('/addeemployees', [EmployeeController::class, 'registerForm'])->name('register.form');
  Route::post('/addemployees', [EmployeeController::class, 'store'])->name('employees.store');

  // Manage Roles route
  Route::get('/manageroles', [ManageRoleController::class, 'activelist']);
  Route::post('/updaterole', [ManageRoleController::class, 'updateRoles'])->name('updateRoles');

  //  History route

  Route::get('/history', [HistoryController::class, 'history']);
  Route::post('/historystar', [HistoryController::class, 'history'])->name('star.history');

// TEAM INCHARGE ROUTES

    // Home page route
  Route::get('/hrhome', [HRhomeController::class, 'index'])->middleware('login');
  Route::post('/hrhome', [HRhomeController::class, 'giveStars'])->name('give.Stars');

  // Manage Approvals route
  Route::get('/hrmanageapprovals', [HRmanageaprovalsController::class, 'pendingList'])->name('pendinglist');
  Route::post('/hraccept', [HRmanageaprovalsController::class, 'acceptstar'])->name('accept.star'); 
  Route::post('/hrreject', [HRmanageaprovalsController::class, 'rejectstar'])->name('reject.star');
 
  // Manage Employees route
  Route::get('/hrmanageemployees', [HRmanageemployeesController::class, 'employeeList'])->name('employeeList');
  Route::get('/hraddeemployees', [HREmployeesController::class, 'registerForm'])->name('registerForm');
  Route::post('/hraddemployees', [HREmployeesController::class, 'store'])->name('employeesStore');

// TEAM MEMBER ROUTES
  Route::get('/emphome', [TMhomeController::class, 'index'])->middleware('login');
  Route::post('/emphome', [TMhomeController::class, 'giveStars'])->name('givestar');
