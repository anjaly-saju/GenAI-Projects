<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('star_program_details', function (Blueprint $table) {
            $table->id();
            $table->string('from_emp_id');
            $table->string('from_emp_name');
            $table->string('to_emp_id');
            $table->string('to_emp_name');
            $table->integer('star_points');
            $table->date('date');
            $table->text('reason'); 
            $table->enum('action',['Pending', 'Accept', 'Reject'])->default('Pending');
            $table->text('remark')->nullable();
            $table->timestamps();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('star_program_details');
    }
};
