<!-- resources/views/auth/login.blade.php -->

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<style>
    body {
        font-family: 'Arial', sans-serif; /* Change 'Arial' to the desired font */
        background-image: url('./images/newlogin_page.jpg'); /* image is kept in public folder */
        

        background-size: cover;
       
    }

    :root {
        --light-grey: #E1E1E1;
    }

    h1 {
        margin: 1% !important;
        font-size: medium !important;
        text-align: center;
    }

    .container {
        min-height: 60vh;
    }

    .btn-container {
        display: flex;
        justify-content: center;
    }

    .submit-btn {
        background-color: red !important;
        color: white !important;
    }

    .form-container {
        margin: auto;
        padding: 2%;
        width: 50%;
        border: 1px solid var(--light-grey);
        box-shadow: 0 2px 10px var(--light-grey);
        margin-top: 138px;
        border-radius: 10%;
        background: #b2b1ff38;
    }

    .header-nav {
        display: flex;
        justify-content: space-between;
        align-items: center;
        position: sticky;
        top: 0;
        background-color: white;
        z-index: 5;
    }

    .header-nav>div {
        margin: 1%;
    }

    .logo-container {
        width: 10%;
    }

    .logo-container img {
        width: 100%;
    }

    .footer {
        position: fixed;
        bottom: 0;
        width: 100%;
        height: 2rem;
        line-height: 2rem;
        background-color: #004e70;
        z-index: 1;
        color: white;
        text-align: center;
    }
</style>
<body>
   
    <div class="container">
        <div class="form-container">
            <div class="alert alert-danger" role="alert" style="display: none;" id="errorAlert">Incorrect login details.
                Please try again.
            </div>
            <h1><strong>Login</strong></h1>

    <form method="POST" action="<?php echo e(route('login.authenticate')); ?>">
        <?php echo csrf_field(); ?> <!-- CSRF Protection -->
        
        <div class="form-group">
                <label for="emp_id">Employee ID</label>
                <input type="text" name="emp_id" id="emp_id" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" id="password" class="form-control" required>
            </div>
            <div>
              <?php if($errors->any()): ?>
              <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <h5 class="error-message"><?php echo e($error); ?></h5>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
               </div>
               <?php endif; ?>
            </div>
            <div class="btn-container">
                    <button type="submit" class="btn submit-btn">Submit</button>
                </div>
        </form>
        </div>
    </div>
      
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous">
    </script>

    
                  
</body>
</html>
<?php /**PATH C:\xampp\htdocs\proton_star\resources\views/auth/login.blade.php ENDPATH**/ ?>