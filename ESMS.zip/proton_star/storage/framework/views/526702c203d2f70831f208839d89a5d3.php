
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Approvals</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.17.0/font/bootstrap-icons.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

    <style>
        body {
            font-family: 'Arial', sans-serif; 
            padding-top: 56px; /* Adjust this value based on your top navbar height */
        }

        .top-header {
            background-color: #020016; /* Set your preferred background color */
            color: white;
            padding: 10px;
        }

        .sidebar {
            position: fixed;
            top: 56px; /* Adjust this value based on your top navbar height */
            left: 0;
            bottom: 0;
            width: 250px;
            background-color: #020016; /* Set your preferred background color */
        }

        .sidebar-header {
            padding: 15px;
            text-align: center;
        }

        .content {
            
            padding: 15px;
        }
        .sidebar .navbar-nav .nav-item > a {
        color:#ffffff ;
        
        }
        .container {
        min-height: 31vh;
        }
        .form-control {
        display: block;
        width: 100%;
        height: calc(1.5em + .75rem + 2px);
        padding: .375rem .75rem;
        font-size: 1rem;
        font-weight: 400;
        line-height: 1.5;
        color: #495057;
        background-color: #fff;
        background-clip: padding-box;
        border: 1px solid #ced4da;
        border-radius: .25rem;
        transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
        }
        .form-container {
        margin: auto;
        padding: 2%;
        width: 35%;
        border: 1px solid var(--light-grey);
        box-shadow: 0 2px 10px var(--light-grey);
        margin-top: 138px;
        border-radius: 10%;
        background:   #b2b1ff20;
        }
        .star_submitbtn,
        .clear_submitbtn {
        background-color: red;
        cursor: pointer;
        color: white;
        border: none;
        border-radius: 5px;
        transition: background-color 0.3s;
       }
         
     .submenu a {
     text-decoration: none;
     color: white;
     }

     .submenu a:hover {
     color: grey;
     }
     .submenu.show {
     display: block;
     }

    </style>
</head>
<body> 
     <!-- Top Header -->
     <nav class="navbar navbar-dark fixed-top bg-custom-white top-header" style="height: 61px; border-radius: 10px">
    <a class="navbar-brand" style="margin-top: -66px;" href="#"> </a>
    <div class="sidebar-header">
        <div class="star-heading" style=" margin-top: -22px;margin-right: 584px;">
            <h3><strong style="font-family: space-age;color: white;">Logo</strong></h3>
               
        </div>
    </div>
    
    </nav>

    <!-- Sidebar -->
    <nav class="navbar navbar-dark fixed-top sidebar" style="margin-top: -56px; border-radius: 25px;">
    <!-- Add your sidebar links or content here -->
    <div class="nav-item" style="margin-top: -244px;">
    <a class="nav-link" href="<?php echo e(route('logout')); ?>">
        <span style="color: white;"><strong>Hi <?php echo e($data->name); ?> </strong></span>
    </a>
</div> 

    <ul class="navbar-nav" style="margin-top: -395px;margin-left: 26px">
        <br>
         
        <li class="nav-item">
    <a class="nav-link" href="home">
        <i class="fas fa-home"></i> <strong>Home</strong>
    </a>
</li>
 
<li class="nav-item">
    <a class="nav-link" href="manageapprovals">
        <i class="fas fa-check-circle"></i> <strong>Manage Approvals<i class="fas fa-angle-right dropdown"style="margin-left: 19px;"></i></strong>
    </a>
    <ul class="submenu">
    <li><a href="#pending-list" id="qp-sub-1"><i class="fas fa-clock"></i> Pending List</a></li>
    <li><a href="#accepted-list" id="qp-sub-2"><i class="fas fa-check-circle"></i> Accepted List</a></li>
    <li><a href="#rejected-list" id="qp-sub-3"><i class="fas fa-times-circle"></i> Rejected List</a></li>
</ul>
</li>
 
<li class="nav-item">
    <a class="nav-link" href="manageemployees">
        <i class="fas fa-users"></i> <strong>Manage Employees<i class="fas fa-angle-right dropdown"style="margin-left: 6px;"></i></strong>
    </a>
    <ul class="submenu">
    <li><a href="manageemployees#active-list"><i class="fas fa-check-circle"></i> Active List</a></li>
    <li><a href="manageemployees#inactive-list"><i class="fas fa-times-circle"></i> Inactive List</a></li>
    <li><a href="manageemployees#add-employee"><i class="fas fa-user-plus"></i> Add Employee</a></li>
    </ul>
</li>
 
<li class="nav-item">
    <a class="nav-link" href="manageroles">
        <i class="fas fa-cogs"></i> <strong>Manage Roles</strong>
    </a>
</li>
 
<li class="nav-item">
    <a class="nav-link" href="history">
        <i class="fas fa-history"></i> <strong>History</strong>
    </a>
</li>

    <li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('password.change.form')); ?>">
        <i class="fas fa-key"></i> <strong>Change Password</strong>
    </a>
</li>
<li class="nav-item">
    <a class="nav-link" href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
        <i class="fas fa-sign-out-alt"></i> <strong>Logout</strong>
    </a>
    <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>" style="display: none;">
        <?php echo csrf_field(); ?> <!-- CSRF Protection -->
        <button class="dropdown-item" type="submit">Logout</button>
    </form>
</li>

  </ul>
  
    </nav>
    <div class="container" style="margin-left: 262px;">
    <br>


<div id="pending-list" class="container qp-sub-co-1" style="width: 765px; margin-left: 10px;">
<hr>
<h3>Pending Approvals</h3>
<hr>  
<?php if(isset($pendingList) && count($pendingList) > 0): ?>
<table class="table table-bordered">
            <thead>
                <tr>
                    <th>Star From</th>
                    <th>Star To</th>
                    <th>Star Points</th>
                    <th>Date</th>
                    <th>Reason</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pendingList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($entry->from_emp_name); ?></td>
                        <td><?php echo e($entry->to_emp_name); ?></td>
                        <td><?php echo e($entry->star_points); ?></td>
                        <td><?php echo e($entry->date); ?></td>
                        <td><?php echo e($entry->reason); ?></td>
                        <td> 
                            <form action="<?php echo e(route('acceptstar')); ?>" method="POST">
                                <?php echo csrf_field(); ?> <!-- Include CSRF token for Laravel form submission -->
                                <input type="hidden" name="id" value="<?php echo e($entry->id); ?>"> <!-- Include the ID of the entry -->
                                <div class="button-container">
                                    <button type="submit" class="btn star_submitbtn">Accept</button>
                                </div>
                            </form>
                            </td>
                            <td> 
                            <form action="<?php echo e(route('rejectstar')); ?>" method="POST">
                                <?php echo csrf_field(); ?> <!-- Include CSRF token for Laravel form submission -->
                                <input type="hidden" name="id" value="<?php echo e($entry->id); ?>"> <!-- Include the ID of the entry -->
                                <div class="button-container">
                                    <button type="submit" class="btn star_submitbtn">Reject</button>
                                </div>
                            </form>
                         
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php else: ?>
    <p>No pending entries found.</p>
<?php endif; ?>
    </div>




<div id="accepted-list" class="container qp-sub-co-2" style="width: 765px; margin-left: 10px;">
<hr>
<h3>Accepted List</h3>
<hr>  
<?php if(isset($acceptList) && count($acceptList) > 0): ?>      
<table class="table table-bordered">
            <thead>
                <tr>
                    <th>Star From</th>
                    <th>Star To</th>
                    <th>Star Points</th>
                    <th>Date</th>
                    <th>Reason</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $acceptList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($entry->from_emp_name); ?></td>
                        <td><?php echo e($entry->to_emp_name); ?></td>
                        <td><?php echo e($entry->star_points); ?></td>
                        <td><?php echo e($entry->date); ?></td>
                        <td><?php echo e($entry->reason); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php else: ?>
    <p>No accepted entries found.</p>
<?php endif; ?>
    </div>




<div id="rejected-list" class="container qp-sub-co-3" style="width: 765px; margin-left: 10px;">
<hr>
<h3>Reject List</h3>
<hr> 
<?php if(isset($rejectList) && count($rejectList) > 0): ?>       
<table class="table table-bordered">
            <thead>
                <tr>
                    <th>Star From</th>
                    <th>Star To</th>
                    <th>Star Points</th>
                    <th>Date</th>
                    <th>Reason</th>
                    <th>Remark</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $rejectList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($entry->from_emp_name); ?></td>
                        <td><?php echo e($entry->to_emp_name); ?></td>
                        <td><?php echo e($entry->star_points); ?></td>
                        <td><?php echo e($entry->date); ?></td>
                        <td><?php echo e($entry->reason); ?></td>
                        <td><?php echo e($entry->remark); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php else: ?>
    <p>No rejected entries found.</p>
<?php endif; ?>
    </div>


</div>
<script>
$(document).ready(function () {
    $(" .qp-sub-co-2, .qp-sub-co-3").hide(); // Hide all submenu contents initially

    $(".submenu a").on("click", function () {
        // Remove 'active' class from all submenu items
        $(".submenu a").removeClass("active");

        // Add 'active' class to the clicked submenu item
        $(this).addClass("active");

        // Hide all content sections
        $(".qp-sub-co-1, .qp-sub-co-2, .qp-sub-co-3").hide();

        // Show the corresponding content section based on the clicked submenu item
        if ($(this).attr("id") === "qp-sub-1") {
            $(".qp-sub-co-1").show();
        } else if ($(this).attr("id") === "qp-sub-2") {
            $(".qp-sub-co-2").show();
        } else if ($(this).attr("id") === "qp-sub-3") {
            $(".qp-sub-co-3").show();
        }
    });
});
</script>
 
</body>
</html><?php /**PATH C:\xampp\htdocs\proton_star\resources\views/admin/manageapprovals.blade.php ENDPATH**/ ?>