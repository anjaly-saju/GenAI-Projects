<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Employees</title> 
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>

    <style>
        body {
            font-family: 'Arial', sans-serif; 
            padding-top: 56px; /* Adjust this value based on your top navbar height */
        }

        .top-header {
            background-color: #020016; /* Set your preferred background color */
            color: white;
            padding: 10px;
        }

        .sidebar {
            position: fixed;
            top: 56px; /* Adjust this value based on your top navbar height */
            left: 0;
            bottom: 0;
            width: 250px;
            background-color: #020016; /* Set your preferred background color */
        }

        .sidebar-header {
            padding: 15px;
            text-align: center;
        }

        .content {
            
            padding: 15px;
        }
        .sidebar .navbar-nav .nav-item > a {
        color:#ffffff ;
        
        }
        .container {
        min-height: 11vh;
        }
        .form-control {
        display: block;
        width: 100%;
        height: calc(1.5em + .75rem + 2px);
        padding: .375rem .75rem;
        font-size: 1rem;
        font-weight: 400;
        line-height: 1.5;
        color: #495057;
        background-color: #fff;
        background-clip: padding-box;
        border: 1px solid #ced4da;
        border-radius: .25rem;
        transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
        }
        .form-container {
        margin: auto;
        padding: 2%;
        width: 35%;
        border: 1px solid var(--light-grey);
        box-shadow: 0 2px 10px var(--light-grey);
        margin-top: 138px;
        border-radius: 10%;
        background:   #b2b1ff20;
        }
        .star_submitbtn,
        .clear_submitbtn {
        background-color: red;
        cursor: pointer;
        color: white;
        border: none;
        border-radius: 5px;
        transition: background-color 0.3s;
       }
       .stars {
       width: 30%; /* Adjust the width as needed */
       /* margin-left: 20px; */
       margin-top: 20px; /* Adjust the top margin as needed */
       margin-bottom: 10px; /* Adjust the bottom margin as needed */
       /* border: 2px solid rgb(220, 250, 52); */
       height: 60vh;
       display: flex;
       flex-direction: column;
       /* justify-content: space-between; */
       align-items: flex-start;
       }
       .intro1 {
    
       list-style-type: none;
       }

      .intro2 {
       list-style-type: none;
      }

     .instructions {
     }

      
     .submenu a {
     text-decoration: none;
     color: white;
     }

     .submenu a:hover {
     color: grey;
     }
     .submenu.show {
     display: block;
     }

    </style>
</head>

<body>

    <!-- Top Header -->
    <nav class="navbar navbar-dark fixed-top bg-custom-white top-header" style="height: 61px; border-radius: 10px">
    <a class="navbar-brand" style="margin-top: -66px;" href="#"> </a>
    <div class="sidebar-header">
        <div class="star-heading" style=" margin-top: -22px;margin-right: 584px;">
            <h3><strong style="font-family: space-age;color: white;">Logo</strong></h3>
               
        </div>
    </div>
    
    </nav>

    <!-- Sidebar -->
    <nav class="navbar navbar-dark fixed-top sidebar" style="margin-top: -56px; border-radius: 25px;">
    <!-- Add your sidebar links or content here -->
    <div class="nav-item" style="margin-top: -244px;">
    <a class="nav-link" href="<?php echo e(route('logout')); ?>">
        <span style="color: white;"><strong>Hi <?php echo e($data->name); ?> </strong></span>
    </a>
</div> 

<ul class="navbar-nav" style="margin-top: -395px;margin-left: 26px">
        <br>
         
        <li class="nav-item">
    <a class="nav-link" href="hrhome">
        <i class="fas fa-home"></i> <strong>Home</strong>
    </a>
</li>
 
<li class="nav-item">
    <a class="nav-link" href="hrmanageapprovals">
        <i class="fas fa-check-circle"></i> <strong>Manage Approvals<i class="fas fa-angle-right dropdown"style="margin-left: 19px;"></i></strong>
    </a>
    <ul class="submenu">
    <li><a href="hrmanageapprovals#pending-list" id="qp-sub-1"><i class="fas fa-clock"></i> Pending List</a></li>
    <li><a href="hrmanageapprovals#accepted-list" id="qp-sub-2"><i class="fas fa-check-circle"></i> Accepted List</a></li>
    <li><a href="hrmanageapprovals#rejected-list" id="qp-sub-3"><i class="fas fa-times-circle"></i> Rejected List</a></li>
</ul>
</li>
 
<li class="nav-item">
    <a class="nav-link" href="manageemployees">
        <i class="fas fa-users"></i> <strong>Manage Employees<i class="fas fa-angle-right dropdown"style="margin-left: 6px;"></i></strong>
    </a>
    <ul class="submenu">
    <li><a href="#active-list"id="qp-sub-1"><i class="fas fa-check-circle"></i> Active List</a></li>
    <li><a href="#inactive-list"id="qp-sub-2"><i class="fas fa-times-circle"></i> Inactive List</a></li>
    <li><a href="#add-employee"id="qp-sub-3"><i class="fas fa-user-plus"></i> Add Employee</a></li>
    </ul>
</li>
 
  
    <li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('password.change.form')); ?>">
        <i class="fas fa-key"></i> <strong>Change Password</strong>
    </a>
</li>
<li class="nav-item">
    <a class="nav-link" href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
        <i class="fas fa-sign-out-alt"></i> <strong>Logout</strong>
    </a>
    <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>" style="display: none;">
        <?php echo csrf_field(); ?> <!-- CSRF Protection -->
        <button class="dropdown-item" type="submit">Logout</button>
    </form>
</li>

  </ul>
  
    </nav>
    <div class="container" style="margin-left: 262px;">
    <br>
    
<div id="active-list" class="container qp-sub-co-1" style="width: 765px; margin-left: 10px;">
<hr>
<h3>Active Employees</h3>
<hr>
<?php if(isset($activeList) && count($activeList) > 0): ?>        
<table class="table table-bordered">
    
        <thead>
            <tr>
                <th>Emp Name</th>
                <th>Emp ID</th>
                <th>Star Points</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $activeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($entry->name); ?></td>
                    <td><?php echo e($entry->emp_id); ?></td>
                    <td><?php echo e($entry->star_points); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    
<?php else: ?>
    <p>No active employees found.</p>
<?php endif; ?>
</div>

<div id="inactive-list" class="container qp-sub-co-2" style="width: 765px; margin-left: 10px;">
<hr>
<h3>Inactive Employees</h3>
<hr>
<?php if(isset($inactiveList) && count($inactiveList) > 0): ?>       
<table class="table table-bordered">
        <thead>
            <tr>
                <th>Emp Name</th>
                <th>Emp ID</th>
                <th>Star Points</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $inactiveList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($entry->name); ?></td>
                    <td><?php echo e($entry->emp_id); ?></td>
                    <td><?php echo e($entry->star_points); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    
<?php else: ?>
    <p>No inactive employees found.</p>
<?php endif; ?>
</div>

<div id="add-employee" class="container qp-sub-co-3" style="width: 765px; margin-left: 10px;">
<hr>
<h3>Add Employees</h3>
<hr>
<form method="POST" action="<?php echo e(route('employeesStore')); ?>">
    <?php echo csrf_field(); ?>
    <input type="text" name="emp_id" placeholder="Employee ID"><br>
    <input type="text" name="name" placeholder="Name"><br>
    <input type="password" name="password" placeholder="Password"><br>
    <input type="date" name="date_of_joining" placeholder="Date of Joining"><br>
   
<br>
    <!-- Other fields as needed -->
    <div class="button-container">
            <button type="submit" id="submitBtn" class="btn star_submitbtn">Submit</button>
             
            </div>
    </div>
</form>
    </div>
    <script>
$(document).ready(function () {
    $(".qp-sub-co-1, .qp-sub-co-2, .qp-sub-co-3").hide(); // Hide all submenu contents initially

    $(".submenu a").on("click", function () {
        // Remove 'active' class from all submenu items
        $(".submenu a").removeClass("active");

        // Add 'active' class to the clicked submenu item
        $(this).addClass("active");

        // Hide all content sections
        $(".qp-sub-co-1, .qp-sub-co-2, .qp-sub-co-3").hide();

        // Show the corresponding content section based on the clicked submenu item
        if ($(this).attr("id") === "qp-sub-1") {
            $(".qp-sub-co-1").show();
        } else if ($(this).attr("id") === "qp-sub-2") {
            $(".qp-sub-co-2").show();
        } else if ($(this).attr("id") === "qp-sub-3") {
            $(".qp-sub-co-3").show();
        }
    });
});
</script>
</body>
</html><?php /**PATH C:\xampp\htdocs\proton_star\resources\views/teamincharge/hrmanageemployees.blade.php ENDPATH**/ ?>