from django.contrib.auth.models import User
from django.core.validators import RegexValidator
from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver

class UserProfile(models.Model):
    id = models.BigAutoField(primary_key=True)
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    role = models.CharField(max_length=200, choices=[('seller', 'Seller'), ('customer', 'Customer')])
    phone_number = models.CharField(max_length=200, validators=[RegexValidator(r'^\+?\d{10}$', 'Phone number must be 10 digits with optional country code.')])
    address = models.CharField(max_length=255)

@receiver(post_save, sender=User)
def create_user_profile(sender, instance, created, **kwargs):
    if created:
        UserProfile.objects.create(user=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    try:
        instance.userprofile.save()
    except UserProfile.DoesNotExist:
        pass


class Category(models.Model):
    GADGETS = 'Gadgets'
    CLOTHES = 'Clothes'
    FOOTWEAR = 'Footwear'
    BAGS = 'Bags'
    APPLIANCES = 'Appliances'

    CATEGORY_CHOICES = [
        (GADGETS, 'Gadgets'),
        (CLOTHES, 'Clothes'),
        (FOOTWEAR, 'Footwear'),
        (BAGS, 'Bags'),
        (APPLIANCES, 'Appliances'),
    ]

    category = models.CharField(max_length=100, choices=CATEGORY_CHOICES, unique=True)

    def __str__(self):
        return self.category

class Product(models.Model):
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE, default=None)
    image = models.ImageField(upload_to='product_images/')
    title = models.CharField(max_length=200)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.TextField()

    def __str__(self):
        return self.title


class Order(models.Model):
    ORDER_PLACED = 'Order Placed'
    ORDER_CANCELLED = 'Order Cancelled'
    ORDER_FULFILLED = 'Order Fulfilled'

    ORDER_STATUS_CHOICES = [
        (ORDER_PLACED, 'Order Placed'),
        (ORDER_CANCELLED, 'Order Cancelled'),
        (ORDER_FULFILLED, 'Order Fulfilled'),
    ]
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE, default=None)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField()
    status = models.CharField(max_length=100, choices=ORDER_STATUS_CHOICES, default=ORDER_PLACED)

    def __str__(self):
        return f"{self.product.title} - {self.status}"

class Cart(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField()
    user = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return f"Cart item {self.id} - {self.product.title} - Quantity: {self.quantity} - User: {self.user.username}"