from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.shortcuts import get_object_or_404
from django.db.models import F
import json
from .models import UserProfile,Product,Category,Cart,Order
from django.contrib.auth import update_session_auth_hash


def register(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')
        name = request.POST.get('name')
        email = request.POST.get('email')
        role = request.POST.get('role')
        phone_number = request.POST.get('phone_number')
        address = request.POST.get('address')

        if password1 != password2:
            messages.error(request, "Passwords do not match")
            return render(request, 'register.html')

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists")
            return render(request, 'register.html')

        # Create the User instance
        user = User.objects.create_user(username=username, password=password1, email=email)

        # Create the UserProfile instance
        profile = UserProfile.objects.create(user=user, name=name, role=role, phone_number=phone_number, address=address)
        
        # Save the UserProfile instance
        profile.save()

        messages.success(request, "Account created successfully.")
        return redirect('login')

    return render(request, 'register.html')


def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            try:
                profile = UserProfile.objects.get(user=user)
                if profile.role == 'seller':
                    return redirect('dashboard')
                else:
                    return redirect('home')
            except UserProfile.DoesNotExist:
                messages.error(request, "User profile not found")
                return redirect('login')
        else:
            messages.error(request, "Invalid username or password")
            return redirect('login')
    return render(request, 'login.html')

def logout_view(request):
    logout(request)
    return redirect('login')

# Change password page
@login_required
def change_password(request):
    if request.method == 'POST':
        current_password = request.POST.get('old_password')
        new_password1 = request.POST.get('new_password1')
        new_password2 = request.POST.get('new_password2')

        if new_password1 != new_password2:
            messages.error(request, "Passwords do not match")
        else:
            # Check if the current password is correct
            if not request.user.check_password(current_password):
                messages.error(request, "Incorrect current password")
            else:
                # Update the user's password
                request.user.set_password(new_password1)
                request.user.save()
                update_session_auth_hash(request, request.user)  # Update session to prevent logout

                messages.success(request, "Password changed successfully")
                  
    return render(request, 'changepassword.html')


# Seller
     # Dashboard Page

@login_required
def dashboard(request):
    return render(request, 'seller/dashboard.html')

     # Product page
@login_required
def products(request):
    user_products = Product.objects.filter(user=request.user)
    categories = Category.objects.all()  # Retrieve all categories
    return render(request, 'seller/products.html', {'user_products': user_products, 'categories': categories})

@require_POST
def add_product(request):
    if request.method == 'POST':
        # Get form data
        title = request.POST.get('title')
        price = request.POST.get('price')
        description = request.POST.get('description')
        image = request.FILES.get('image')
        category_id = request.POST.get('category')  # Assuming you're receiving category ID from the form
        
        # Retrieve Category object from the database
        category = get_object_or_404(Category, id=category_id)
        
        # Get the logged-in user
        user = request.user
        
        # Create Product instance and save
        product = Product.objects.create(
            title=title,
            price=price,
            description=description,
            image=image,
            category=category,  # Assign Category instance, not category_id
            user=user  # Assign the logged-in user
        )
        # Redirect to the products page to prevent form resubmission
        return redirect('products')
    else:
        # Handle GET request (if needed)
        pass

def update_product(request):
    if request.method == 'POST':
        try:
            # Get the product ID from the POST data
            product_id = request.POST.get('product_id')

            # Get the product object from the database
            product = Product.objects.get(pk=product_id)

            # Update the product details with the data from the POST request
            product.title = request.POST.get('title', product.title)
            product.price = request.POST.get('price', product.price)
            product.description = request.POST.get('description', product.description)

            # Save the updated product
            product.save()

            # Return a JSON response indicating success
            return redirect('products')
        except Product.DoesNotExist:
            # Return a JSON response indicating failure (product not found)
            return JsonResponse({'success': False, 'error': 'Product not found'})
        except Exception as e:
            # Return a JSON response indicating failure (generic error)
            return JsonResponse({'success': False, 'error': str(e)})
    else:
        # Return a JSON response indicating failure (invalid request method)
        return JsonResponse({'success': False, 'error': 'Invalid request method'})

def delete_product(request):
    if request.method == 'POST':
        # Get the product ID from the AJAX request
        data = json.loads(request.body)
        product_id = data.get('product_id')

        # Get the product object from the database or return 404 if not found
        product = get_object_or_404(Product, pk=product_id)

        # Delete the product
        product.delete()

        # Return a JSON response indicating success
        return JsonResponse({'success': True})
    else:
        # Return a JSON response indicating failure
        return JsonResponse({'success': False, 'error': 'Invalid request method'})

     # Order Page
@login_required
def orders(request):
    # Retrieve products uploaded by the logged-in seller
    seller_products = Product.objects.filter(user=request.user)

    # Retrieve orders associated with the seller's products along with category information
    seller_orders = Order.objects.filter(product__in=seller_products).annotate(category_name=F('product__category__category'))

    # Pass the orders and category to the template
    return render(request, 'seller/orders.html', {'seller_orders': seller_orders})

def update_order_status(request):
    if request.method == 'POST':
        order_id = request.POST.get('order_id')
        new_status = request.POST.get('status')

        try:
            # Get the order object from the database
            order = Order.objects.get(pk=order_id)

            # Update the status of the order
            order.status = new_status
            order.save()

            messages.success(request, 'Order status updated successfully.')
        except Order.DoesNotExist:
            messages.error(request, 'Order not found.')
        except Exception as e:
            messages.error(request, f'Error updating order status: {str(e)}')

    return redirect('orders')

@login_required
def your_profile(request):
    user = request.user  # Assuming user is authenticated
    user_profile = UserProfile.objects.get(user=user)  # Fetch user profile
    return render(request, 'seller/yourprofile.html', {'user_profile': user_profile})   


# Customer
    # Home Page
@login_required
def home(request):
    return render(request, 'customer/home.html')
    
    # Shop Now Page
@login_required
def shop_now(request):
    categories = Category.objects.all()  # Retrieve all categories
    products_by_category = {}  # Dictionary to store products grouped by category

    # Group products by category
    for category in categories:
        products_in_category = Product.objects.filter(category=category)
        products_by_category[category.category] = products_in_category

    return render(request, 'customer/shopnow.html', {'products_by_category': products_by_category})

@require_POST
def add_cart(request):
    if request.method == 'POST':
        quantity = request.POST.get('quantity')
        product_id = request.POST.get('product_id')

        # Get the logged-in user
        user = request.user

        # Create Cart instance and save
        cart = Cart.objects.create(
            quantity=quantity,
            product_id=product_id,
            user=user  # Assign the logged-in user
        )
        # Redirect to the products page to prevent form resubmission
        return redirect('shop_now')
    else:
        # Handle GET request (if needed)
        pass

    # Cart Page
@login_required
def cart(request):
    # Retrieve products in the cart for the logged-in user
    user_cart_products = Cart.objects.filter(user=request.user)

    # Pass the cart products and other necessary data to the template
    return render(request, 'customer/cart.html', {'user_cart_products': user_cart_products})

def remove_cart(request):
    if request.method == 'POST':
        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            product_id = request.POST.get('product_id')
            try:
                # Get the cart item
                cart_item = Cart.objects.filter(product_id=product_id, user=request.user).first()
                if cart_item:
                    # Delete the cart item
                    cart_item.delete()
                    return JsonResponse({'message': 'Item removed from cart successfully'})
                else:
                    return JsonResponse({'error': 'Item not found in cart'}, status=404)
            except Cart.MultipleObjectsReturned:
                return JsonResponse({'error': 'Multiple items found in cart'}, status=500)
        else:
            return JsonResponse({'error': 'Invalid request'}, status=400)

def order_now(request):
    if request.method == 'POST':
        product_id = request.POST.get('product_id')
        quantity = request.POST.get('quantity')

        try:
            # Get the product object using the provided product_id
            product = Product.objects.get(pk=product_id)
            
            # Access the category ID of the product
            category_id = product.category_id

            # Get the logged-in user
            user = request.user

            # Create Order instance and save
            order = Order.objects.create(
                user=user,
                product=product,
                quantity=quantity,
                category_id=category_id  # Assign the category ID
            )

            # Remove the item from the cart
            cart_item = Cart.objects.filter(product_id=product_id, user=user).first()
            if cart_item:
                cart_item.delete()

            # Redirect to the cart page to prevent form resubmission
            return redirect('cart')
        except Product.DoesNotExist:
            # Handle the case where the product does not exist
            return JsonResponse({'error': 'Product not found'}, status=404)
    else:
        # Handle GET request (if needed)
        pass

    # Your Orders Page
@login_required
def your_orders(request):
    # Retrieve orders for the logged-in user
    user_orders = Order.objects.filter(user=request.user)

    # Pass the orders to the template
    return render(request, 'customer/yourorders.html', {'user_orders': user_orders})



def your_account(request):
    user = request.user  # Assuming user is authenticated
    user_profile = UserProfile.objects.get(user=user)  # Fetch user profile
    return render(request, 'customer/youraccount.html', {'user_profile': user_profile})
