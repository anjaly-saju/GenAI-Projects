from django.urls import path
from shopping_app import views
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
   
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('register/', views.register, name='register'),
    path('change_password/', views.change_password, name='change_password'),

    # Seller
    path('seller/dashboard/', views.dashboard, name='dashboard'),
    path('seller/products/', views.products, name='products'),
    path('seller/add_product/', views.add_product, name='add_product'),
    path('seller/update_product/', views.update_product, name='update_product'),
    path('seller/delete_product/', views.delete_product, name='delete_product'),
    path('seller/orders/', views.orders, name='orders'),
    path('seller/update_order_status/', views.update_order_status, name='update_order_status'),
    path('seller/your_profile/', views.your_profile, name='your_profile'),
    
    # Customer
    path('customer/home/', views.home, name='home'),
    path('customer/shop-now/', views.shop_now, name='shop_now'),
    path('customer/add_to_cart/', views.add_cart, name='add_cart'),
    path('customer/cart/', views.cart, name='cart'),
    path('customer/remove_cart/', views.remove_cart, name='remove_cart'),
    path('customer/order_now/', views.order_now, name='order_now'),
    path('customer/your_orders/', views.your_orders, name='your_orders'),
    path('customer/your_account/', views.your_account, name='your_account'),
]


# Serve media files during development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
