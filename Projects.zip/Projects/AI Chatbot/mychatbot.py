import openai

openai.api_key = "sk-proj-HCg0GId0TJ2jg0L9pHzjT3BlbkFJmMbnu0L0ZG6gZvreN1ez"

def chat_with_gpt(prompt):
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a chatbot."},
            {"role": "user", "content": prompt}
        ]
    )
    return response.choices[0].message["content"].strip()

if __name__ == "__main__":
    while True:
        user_input = input("You: ")
        if user_input.lower() in ["quit", "exit", "bye"]:
            break
        response = chat_with_gpt(user_input)
        print("Chatbot:", response)
