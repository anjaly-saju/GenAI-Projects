from flask import Flask, request, render_template
import openai

app = Flask(__name__)

openai.api_key = "sk-proj-HCg0GId0TJ2jg0L9pHzjT3BlbkFJmMbnu0L0ZG6gZvreN1ez"

def chat_with_gpt(prompt):
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a chatbot."},
            {"role": "user", "content": prompt}
        ]
    )
    return response.choices[0].message["content"].strip()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_input = request.form['user_input']
    response = chat_with_gpt(user_input)
    return response

if __name__ == '__main__':
    app.run(debug=True)
