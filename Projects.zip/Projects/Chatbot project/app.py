from flask import Flask, request, jsonify
from flask_limiter import Limiter
import requests
from dotenv import load_dotenv
import os
import time
import traceback

load_dotenv()  # Load environment variables from .env file

app = Flask(__name__)
limiter = Limiter(app)

@app.route('/chat', methods=['POST'])
@limiter.limit("1 per minute")  # Limit requests to 1 per minute
def chat():
    user_message = request.json.get('message')
    api_key = os.getenv('OPENAI_API_KEY')

    if not api_key:
        return jsonify({'error': 'OPENAI_API_KEY is not set'}), 500

    headers = {
        'Authorization': f'Bearer {api_key}',
        'Content-Type': 'application/json',
    }
    data = {
        'model': 'gpt-3.5-turbo',
        'messages': [{'role': 'user', 'content': user_message}]
    }

    try:
        response = requests.post('https://api.openai.com/v1/chat/completions',
                                 json=data, headers=headers)
        if response.status_code == 429:  # If rate limited, apply exponential backoff
            print("Rate limit exceeded. Please wait and try again later.")
            time.sleep(2)  # Wait for 2 seconds before retrying
            response = requests.post('https://api.openai.com/v1/chat/completions',
                                     json=data, headers=headers)
        response.raise_for_status()  # Raise an exception for HTTP errors
        chat_response = response.json()['choices'][0]['message']['content']
        return jsonify({'reply': chat_response})
    except Exception as e:
        traceback.print_exc()  # Print traceback to console for debugging
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=8000)
