import requests

url = 'http://localhost:8000/chat'
message = {'message': 'Hello, how are you?'}

try:
    response = requests.post(url, json=message)
    response.raise_for_status()  # Raise an exception for HTTP errors (4xx or 5xx)
    data = response.json()
    print('Chatbot Response:', data['reply'])
except requests.RequestException as e:
    print('Failed to fetch response from server:', e)
