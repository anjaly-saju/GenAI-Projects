from transformers import pipeline

def main():
    # Load the question answering pipeline
    qa_pipeline = pipeline("question-answering")

    # Get the passage of text from the user
    passage = input("Enter the passage of text: ")

    while True:
        # Prompt the user to ask a question or type 'exit' to quit
        question = input("Ask a question (type 'exit' to quit): ")

        if question.lower() == 'exit':
            break

        # Use the question answering pipeline to generate an answer
        answer = qa_pipeline(question=question, context=passage)

        # Print the answer
        print("Answer:", answer['answer'])

if __name__ == "__main__":
    main()
